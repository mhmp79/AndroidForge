package com.maseer.konkur;
import android.appwidget.AppWidgetManager;
import android.appwidget.AppWidgetProvider;
import android.content.Context;
public class WeeklyTimelineWidgetProvider extends AppWidgetProvider {
 @Override public void onUpdate(Context c, AppWidgetManager m, int[] ids) { WidgetRenderer.update(c,m,WeeklyTimelineWidgetProvider.class,2); }
 @Override public void onReceive(Context c, android.content.Intent i) { super.onReceive(c,i); if(i!=null && "com.maseer.konkur.UPDATE_WIDGET".equals(i.getAction())) WidgetRenderer.update(c,AppWidgetManager.getInstance(c),WeeklyTimelineWidgetProvider.class,2); }
}
