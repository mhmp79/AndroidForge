package com.maseer.konkur;

import android.app.PendingIntent;
import android.appwidget.AppWidgetManager;
import android.appwidget.AppWidgetProvider;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.widget.RemoteViews;
import org.json.JSONArray;
import org.json.JSONObject;

public class StudyWidgetProvider extends AppWidgetProvider {
    @Override public void onUpdate(Context context, AppWidgetManager manager, int[] ids) { updateAll(context, manager); }
    @Override public void onReceive(Context context, Intent intent) {
        super.onReceive(context, intent);
        if (intent != null && "com.maseer.konkur.UPDATE_WIDGET".equals(intent.getAction())) updateAll(context, AppWidgetManager.getInstance(context));
    }
    static void updateAll(Context context, AppWidgetManager manager) {
        ComponentName component = new ComponentName(context, StudyWidgetProvider.class);
        int[] ids = manager.getAppWidgetIds(component);
        for (int id : ids) updateOne(context, manager, id);
    }
    private static void updateOne(Context context, AppWidgetManager manager, int id) {
        RemoteViews views = new RemoteViews(context.getPackageName(), R.layout.study_widget);
        int minutes = 0, totalTests = 0, correct = 0;
        String today = "";
        try {
            JSONObject state = new JSONObject(context.getSharedPreferences("widget_data", Context.MODE_PRIVATE).getString("state_json", "{}"));
            today = context.getSharedPreferences("widget_data", Context.MODE_PRIVATE).getString("today_key", "");
            JSONArray activities = state.optJSONArray("activities");
            if (activities != null) for (int i=0;i<activities.length();i++) {
                JSONObject a = activities.optJSONObject(i); if (a == null || !today.equals(a.optString("date"))) continue;
                String subject = a.optString("subject", "");
                if ("سایر".equals(subject)) continue;
                int m = a.optInt("minutes", Math.max(0, a.optInt("endMin")-a.optInt("startMin")));
                minutes += Math.max(0,m);
                JSONObject tests = a.optJSONObject("tests");
                if (tests != null) { int c=tests.optInt("correct"), w=tests.optInt("wrong"), b=tests.optInt("blank"); totalTests += c+w+b; correct += c; }
            }
            JSONArray exams = state.optJSONArray("exams");
            if (exams != null) for (int i=0;i<exams.length();i++) {
                JSONObject e=exams.optJSONObject(i); if(e==null || !today.equals(e.optString("date")) || !e.optBoolean("hasResults")) continue;
                minutes += Math.max(0, e.optInt("endMin")-e.optInt("startMin"));
            }
        } catch (Exception ignored) {}
        String hourText = String.format(java.util.Locale.US, "مطالعه: %d ساعت و %d دقیقه", minutes/60, minutes%60);
        views.setTextViewText(R.id.widget_hours, hourText);
        views.setTextViewText(R.id.widget_tests, "تست: " + fa(totalTests) + " · درست: " + fa(correct));
        views.setTextViewText(R.id.widget_title, "مسیر کنکور · آمار امروز");
        Intent launch = context.getPackageManager().getLaunchIntentForPackage(context.getPackageName());
        if (launch != null) {
            PendingIntent pi = PendingIntent.getActivity(context, 0, launch, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
            views.setOnClickPendingIntent(R.id.widget_title, pi); views.setOnClickPendingIntent(R.id.widget_hours, pi); views.setOnClickPendingIntent(R.id.widget_tests, pi); views.setOnClickPendingIntent(R.id.widget_hint, pi);
        }
        manager.updateAppWidget(id, views);
    }
    private static String fa(int n) { return String.valueOf(n).replace('0','۰').replace('1','۱').replace('2','۲').replace('3','۳').replace('4','۴').replace('5','۵').replace('6','۶').replace('7','۷').replace('8','۸').replace('9','۹'); }
}
