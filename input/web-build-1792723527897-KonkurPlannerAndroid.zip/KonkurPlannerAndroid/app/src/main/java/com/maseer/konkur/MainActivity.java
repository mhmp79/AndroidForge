package com.maseer.konkur;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

public class MainActivity extends Activity {
    private WebView webView;
    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        webView = new WebView(this);
        setContentView(webView);
        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setAllowFileAccess(true);
        settings.setAllowContentAccess(true);
        settings.setDatabaseEnabled(true);
        webView.setWebViewClient(new WebViewClient());
        webView.setWebChromeClient(new WebChromeClient());
        webView.addJavascriptInterface(new WidgetBridge(this), "AndroidBridge");
        webView.loadUrl("file:///android_asset/index.html");
    }
    @Override public void onBackPressed() {
        if (webView != null && webView.canGoBack()) webView.goBack(); else super.onBackPressed();
    }
    public static class WidgetBridge {
        private final Context context;
        WidgetBridge(Context c) { context = c.getApplicationContext(); }
        @JavascriptInterface public void saveState(String json, String todayKey, String weekKeysJson, String monthPrefix) {
            context.getSharedPreferences("widget_data", Context.MODE_PRIVATE).edit()
                .putString("state_json", json == null ? "{}" : json)
                .putString("today_key", todayKey == null ? "" : todayKey)
                .putString("week_keys_json", weekKeysJson == null ? "[]" : weekKeysJson)
                .putString("month_prefix", monthPrefix == null ? "" : monthPrefix).apply();
            String action = "com.maseer.konkur.UPDATE_WIDGET";
            Class<?>[] providers = { StudyWidgetProvider.class, DailyTimelineWidgetProvider.class, WeeklyTimelineWidgetProvider.class, MinimalStatsWidgetProvider.class };
            for (Class<?> provider : providers) {
                Intent i = new Intent(context, provider);
                i.setAction(action);
                context.sendBroadcast(i);
            }
        }
    }
}
