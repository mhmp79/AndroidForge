package com.maseer.konkur;
import android.appwidget.AppWidgetManager;
import android.appwidget.AppWidgetProvider;
import android.content.Context;
public class DailyTimelineWidgetProvider extends AppWidgetProvider {
 @Override public void onUpdate(Context c, AppWidgetManager m, int[] ids) { WidgetRenderer.update(c,m,DailyTimelineWidgetProvider.class,1); }
 @Override public void onReceive(Context c, android.content.Intent i) { super.onReceive(c,i); if(i!=null && "com.maseer.konkur.UPDATE_WIDGET".equals(i.getAction())) WidgetRenderer.update(c,AppWidgetManager.getInstance(c),DailyTimelineWidgetProvider.class,1); }
}
