package com.maseer.konkur;

import android.app.PendingIntent;
import android.appwidget.AppWidgetManager;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.view.View;
import android.widget.RemoteViews;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.RectF;
import android.graphics.Typeface;
import org.json.JSONArray;
import org.json.JSONObject;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

final class WidgetRenderer {
    private WidgetRenderer() {}
    static final String OTHER = "سایر";
    static final String EXAM = "آزمون";

    static void update(Context c, AppWidgetManager manager, Class<?> provider, int kind) {
        int[] ids = manager.getAppWidgetIds(new ComponentName(c, provider));
        for (int id : ids) renderOne(c, manager, id, kind);
    }
    static void updateOne(Context c, AppWidgetManager manager, int id, int kind) { renderOne(c, manager, id, kind); }

    private static void renderOne(Context c, AppWidgetManager manager, int id, int kind) {
        int layout = kind == 1 ? R.layout.widget_daily_timeline : kind == 2 ? R.layout.widget_weekly_timeline : R.layout.widget_minimal_stats;
        RemoteViews v = new RemoteViews(c.getPackageName(), layout);
        JSONObject state = new JSONObject();
        String today = "", monthPrefix = "";
        JSONArray weekKeys = new JSONArray();
        try {
            android.content.SharedPreferences p = c.getSharedPreferences("widget_data", Context.MODE_PRIVATE);
            state = new JSONObject(p.getString("state_json", "{}"));
            today = p.getString("today_key", "");
            monthPrefix = p.getString("month_prefix", today.length() >= 7 ? today.substring(0,7) : "");
            weekKeys = new JSONArray(p.getString("week_keys_json", "[]"));
        } catch (Exception ignored) {}

        Intent launch = c.getPackageManager().getLaunchIntentForPackage(c.getPackageName());
        if (launch != null) {
            PendingIntent pi = PendingIntent.getActivity(c, 700 + kind, launch, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
            int[] clickIds = kind == 1 ? new int[]{R.id.daily_root} : kind == 2 ? new int[]{R.id.weekly_root} : new int[]{R.id.stats_root};
            for (int clickId : clickIds) v.setOnClickPendingIntent(clickId, pi);
        }
        if (kind == 1) fillDaily(v, state, today);
        else if (kind == 2) fillWeekly(v, state, weekKeys, today);
        else fillStats(v, state, today, monthPrefix, weekKeys);
        manager.updateAppWidget(id, v);
    }

    private static void fillDaily(RemoteViews v, JSONObject state, String today) {
        v.setTextViewText(R.id.daily_title, "تایم‌لاین امروز");
        int startHour = state.optJSONObject("settings") == null ? 6 : state.optJSONObject("settings").optInt("tbStartHour", 6);
        int endHour = state.optJSONObject("settings") == null ? 24 : state.optJSONObject("settings").optInt("tbEndHour", 24);
        startHour = Math.max(0, Math.min(23, startHour)); endHour = Math.max(startHour + 1, Math.min(24, endHour));
        List<Slot> slots = slotsForDay(state, today);
        v.setTextViewText(R.id.daily_empty, slots.isEmpty() ? "برای امروز برنامه‌ای ثبت نشده" : "بلوک‌های رنگی برنامه · لمس برای باز کردن");
        Bitmap bitmap = drawDayTimeline(state, slots, startHour, endHour, 720, 1120);
        v.setImageViewBitmap(R.id.daily_timeline_image, bitmap);
    }

    private static void fillWeekly(RemoteViews v, JSONObject state, JSONArray weekKeys, String today) {
        v.setTextViewText(R.id.weekly_title, "تایم‌لاین هفتگی");
        int startHour = state.optJSONObject("settings") == null ? 6 : state.optJSONObject("settings").optInt("tbStartHour", 6);
        int endHour = state.optJSONObject("settings") == null ? 24 : state.optJSONObject("settings").optInt("tbEndHour", 24);
        startHour = Math.max(0, Math.min(23, startHour)); endHour = Math.max(startHour + 1, Math.min(24, endHour));
        Bitmap bitmap = drawWeekTimeline(state, weekKeys, today, startHour, endHour, 1000, 1120);
        v.setImageViewBitmap(R.id.weekly_timeline_image, bitmap);
    }

    private static List<Slot> slotsForDay(JSONObject state, String key) {
        List<Slot> slots = new ArrayList<>();
        JSONObject plan = state.optJSONObject("plan");
        JSONArray planned = plan == null ? null : plan.optJSONArray(key);
        if (planned != null) for (int i=0;i<planned.length();i++) {
            JSONObject b=planned.optJSONObject(i); if(b==null)continue;
            slots.add(new Slot(b.optInt("startMin"), Math.max(0,b.optInt("durMin")), b.optString("subject","درس"), b.optString("topic",""), "plan"));
        }
        JSONArray activities=state.optJSONArray("activities");
        if(activities!=null) for(int i=0;i<activities.length();i++) {
            JSONObject a=activities.optJSONObject(i); if(a==null || !key.equals(a.optString("date")))continue;
            int st=a.optInt("startMin", -1), en=a.optInt("endMin", -1);
            if(st<0 || en<=st) { int mins=a.optInt("minutes",0); if(mins<=0)continue; en=st<0?0:st+mins; if(st<0)continue; }
            slots.add(new Slot(st,en-st,a.optString("subject","فعالیت"),a.optString("topic",""),"activity"));
        }
        JSONArray exams=state.optJSONArray("exams");
        if(exams!=null) for(int i=0;i<exams.length();i++) { JSONObject e=exams.optJSONObject(i); if(e!=null && key.equals(e.optString("date"))) slots.add(new Slot(e.optInt("startMin"),Math.max(0,e.optInt("endMin")-e.optInt("startMin")),"آزمون",e.optString("name","آزمون"),"exam")); }
        JSONArray sleeps=state.optJSONArray("sleeps");
        if(sleeps!=null) for(int i=0;i<sleeps.length();i++) { JSONObject sl=sleeps.optJSONObject(i); if(sl==null)continue; String date=sl.optString("date",""); int st=sl.optInt("startMin",-1), en=sl.optInt("endMin",-1); if(key.equals(date)&&st>=0&&en>st) slots.add(new Slot(st,en-st,"خواب",sl.optString("note",""),"sleep")); else if(key.equals(sl.optString("endDate","")) && en>0) slots.add(new Slot(0,en,"خواب","","sleep")); }
        Collections.sort(slots, Comparator.comparingInt(a -> a.start));
        return slots;
    }

    private static Bitmap drawDayTimeline(JSONObject state, List<Slot> slots, int startHour, int endHour, int width, int height) {
        Bitmap bmp=Bitmap.createBitmap(width,height,Bitmap.Config.ARGB_8888); Canvas c=new Canvas(bmp);
        Paint p=paint(); p.setAntiAlias(true);
        c.drawColor(Color.TRANSPARENT);
        int left=82, right=width-18, top=18, bottom=height-18;
        float hourH=(bottom-top)/(float)(endHour-startHour);
        p.setTextSize(22); p.setColor(Color.argb(190,190,204,224)); p.setTypeface(Typeface.create("sans-serif",Typeface.NORMAL)); p.setTextAlign(Paint.Align.LEFT);
        for(int h=startHour;h<=endHour;h++) { float y=top+(h-startHour)*hourH; p.setStrokeWidth(1.5f); p.setColor(Color.argb(50,210,225,245)); c.drawLine(left,y,right,y,p); if(h<endHour){p.setColor(Color.argb(200,190,204,224)); c.drawText(faClock(h*60),8,y+7,p);} }
        p.setColor(Color.argb(100,210,225,245)); c.drawLine(left,top,left,bottom,p);
        Map<Slot,Integer> lanes=assignLanes(slots); int maxLane=1; for(Integer l:lanes.values())maxLane=Math.max(maxLane,l+1);
        float laneW=(right-left)/(float)maxLane;
        for(Slot s:slots) {
            int st=Math.max(startHour*60,s.start), en=Math.min(endHour*60,s.start+s.duration); if(en<=st)continue;
            int lane=lanes.getOrDefault(s,0); float x1=left+lane*laneW+3, x2=left+(lane+1)*laneW-3;
            float y1=top+(st-startHour*60)/60f*hourH+2, y2=top+(en-startHour*60)/60f*hourH-2; if(y2-y1<5)y2=y1+5;
            int color=slotColor(state,s); p.setColor(color); c.drawRoundRect(new RectF(x1,y1,x2,y2),13,13,p);
            p.setColor(Color.argb(70,255,255,255)); p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(2); c.drawRoundRect(new RectF(x1,y1,x2,y2),13,13,p); p.setStyle(Paint.Style.FILL);
            if(y2-y1>32 && x2-x1>70) { p.setColor(Color.WHITE); p.setTypeface(Typeface.create("sans-serif",Typeface.BOLD)); p.setTextSize(21); p.setTextAlign(Paint.Align.RIGHT); c.save(); c.clipRect(x1+7,y1+4,x2-7,y2-3); c.drawText(s.subject,x2-9,y1+25,p); if(y2-y1>56&&!s.topic.isEmpty()){p.setTypeface(Typeface.create("sans-serif",Typeface.NORMAL));p.setTextSize(17);c.drawText(s.topic,x2-9,y1+47,p);} if(y2-y1>78){p.setTextSize(16);c.drawText(faClock(s.start)+"–"+faClock(s.start+s.duration),x2-9,y2-12,p);} c.restore(); }
        }
        return bmp;
    }

    private static Bitmap drawWeekTimeline(JSONObject state, JSONArray keys, String today, int startHour, int endHour, int width, int height) {
        Bitmap bmp=Bitmap.createBitmap(width,height,Bitmap.Config.ARGB_8888); Canvas c=new Canvas(bmp); Paint p=paint(); p.setAntiAlias(true); c.drawColor(Color.TRANSPARENT);
        String[] days={"ش","ی","د","س","چ","پ","ج"};
        int left=44,right=width-12,top=68,bottom=height-18; float colW=(right-left)/7f, hourH=(bottom-top)/(float)(endHour-startHour);
        p.setTextAlign(Paint.Align.CENTER); p.setTypeface(Typeface.create("sans-serif",Typeface.BOLD)); p.setTextSize(24);
        for(int d=0;d<7;d++){float x=left+d*colW+colW/2; p.setColor(keys.optString(d,"").equals(today)?Color.rgb(103,232,249):Color.argb(210,220,230,245)); c.drawText(days[d],x,34,p); p.setColor(Color.argb(60,220,230,245)); c.drawRoundRect(new RectF(left+d*colW+3,top,left+(d+1)*colW-3,bottom),8,8,p); }
        p.setTextAlign(Paint.Align.LEFT); p.setTypeface(Typeface.create("sans-serif",Typeface.NORMAL)); p.setTextSize(15);
        for(int h=startHour;h<=endHour;h++){float y=top+(h-startHour)*hourH;p.setColor(Color.argb(60,220,230,245));c.drawLine(left,y,right,y,p);if(h<endHour){p.setColor(Color.argb(185,190,204,224));c.drawText(String.format(Locale.US,"%02d",h),4,y+5,p);}}
        JSONObject plan=state.optJSONObject("plan");
        for(int d=0;d<7;d++) {
            String key=keys.optString(d,""); List<Slot> slots=slotsForDay(state,key); Map<Slot,Integer> lanes=assignLanes(slots);
            int maxLane=1;for(Integer l:lanes.values())maxLane=Math.max(maxLane,l+1); float innerW=(colW-8)/(float)maxLane;
            for(Slot s:slots){int st=Math.max(startHour*60,s.start),en=Math.min(endHour*60,s.start+s.duration);if(en<=st)continue;int lane=lanes.containsKey(s)?lanes.get(s):0;float x1=left+d*colW+4+lane*innerW+1,x2=left+d*colW+4+(lane+1)*innerW-1;float y1=top+(st-startHour*60)/60f*hourH+2,y2=top+(en-startHour*60)/60f*hourH-2;if(y2-y1<4)y2=y1+4;int color=slotColor(state,s);p.setColor(color);c.drawRoundRect(new RectF(x1,y1,x2,y2),6,6,p);p.setColor(Color.argb(80,255,255,255));p.setStyle(Paint.Style.STROKE);p.setStrokeWidth(1.5f);c.drawRoundRect(new RectF(x1,y1,x2,y2),6,6,p);p.setStyle(Paint.Style.FILL); if(y2-y1>44&&x2-x1>24){p.save();p.rotate(-90,(x1+x2)/2,(y1+y2)/2);p.setTextAlign(Paint.Align.CENTER);p.setTextSize(14);p.setTypeface(Typeface.create("sans-serif",Typeface.BOLD));p.setColor(Color.WHITE);c.clipRect(x1+2,y1+2,x2-2,y2-2);c.drawText(s.subject,(x1+x2)/2,(y1+y2)/2+5,p);p.restore();}}
        }
        return bmp;
    }

    private static Map<Slot,Integer> assignLanes(List<Slot> slots) {
        Map<Slot,Integer> result=new HashMap<>(); List<Integer> ends=new ArrayList<>();
        for(Slot s:slots){int lane=0;while(lane<ends.size()&&ends.get(lane)>s.start)lane++;if(lane==ends.size())ends.add(s.start+s.duration);else ends.set(lane,s.start+s.duration);result.put(s,lane);}return result;
    }
    private static int slotColor(JSONObject state, Slot s) {
        if("exam".equals(s.type)||"آزمون".equals(s.subject))return Color.rgb(234,179,8);
        if("sleep".equals(s.type)||"خواب".equals(s.subject))return Color.rgb(100,116,139);
        int base=colorForSubject(state,s.subject,Color.rgb(124,92,255));
        if("activity".equals(s.type))return Color.argb(145,Color.red(base),Color.green(base),Color.blue(base));
        return base;
    }
    private static int colorForSubject(JSONObject state,String name,int fallback) {
        JSONArray subs=state.optJSONArray("subjects"); if(subs!=null)for(int i=0;i<subs.length();i++){JSONObject sub=subs.optJSONObject(i);if(sub!=null&&name.equals(sub.optString("name")))return parseColor(sub.optString("color",""),fallback);}
        if("سایر".equals(name))return Color.rgb(148,163,184); return fallback;
    }
    private static int parseColor(String value,int fallback){try{return Color.parseColor(value);}catch(Exception e){return fallback;}}
    private static Paint paint(){Paint p=new Paint(Paint.ANTI_ALIAS_FLAG);p.setDither(true);return p;}
    private static String faClock(int minutes){int h=Math.max(0,minutes)/60,m=Math.max(0,minutes)%60;return fa(String.format(Locale.US,"%02d:%02d",h,m));}

    private static void fillStats(RemoteViews v, JSONObject state, String today, String monthPrefix, JSONArray weekKeys) {
        int daily = 0, weekly = 0, monthly = 0;
        Map<String, Boolean> week = new HashMap<>(); for(int i=0;i<weekKeys.length();i++) week.put(weekKeys.optString(i,""), true);
        JSONArray activities=state.optJSONArray("activities");
        if (activities != null) for(int i=0;i<activities.length();i++) {
            JSONObject a=activities.optJSONObject(i); if(a==null)continue;
            String date=a.optString("date", ""), subject=a.optString("subject", ""); if(OTHER.equals(subject))continue;
            int mins=a.has("minutes") ? a.optInt("minutes") : Math.max(0,a.optInt("endMin")-a.optInt("startMin"));
            if(date.equals(today)) daily+=Math.max(0,mins);
            if(week.containsKey(date)) weekly+=Math.max(0,mins);
            if(!monthPrefix.isEmpty() && date.startsWith(monthPrefix)) monthly+=Math.max(0,mins);
        }
        JSONArray exams=state.optJSONArray("exams");
        if(exams!=null) for(int i=0;i<exams.length();i++) { JSONObject e=exams.optJSONObject(i); if(e==null || !e.optBoolean("hasResults"))continue; String date=e.optString("date",""); int mins=Math.max(0,e.optInt("endMin")-e.optInt("startMin")); if(date.equals(today))daily+=mins; if(week.containsKey(date))weekly+=mins; if(!monthPrefix.isEmpty()&&date.startsWith(monthPrefix))monthly+=mins; }
        v.setTextViewText(R.id.stats_daily, "روزانه  " + duration(daily));
        v.setTextViewText(R.id.stats_weekly, "هفتگی  " + duration(weekly));
        v.setTextViewText(R.id.stats_monthly, "ماهانه  " + duration(monthly));
        v.setTextViewText(R.id.stats_caption, "زمان فعالیت آموزشی");
    }

    private static String clock(int m) { int h=Math.max(0,m)/60, min=Math.max(0,m)%60; return fa(String.format(Locale.US,"%02d:%02d",h,min)); }
    private static String duration(int m) { m=Math.max(0,m); int h=m/60, min=m%60; return h>0 ? fa(h)+"س "+fa(min)+"د" : fa(min)+"د"; }
    private static String fa(int n) { return fa(String.valueOf(n)); }
    private static String fa(String value) { return value.replace('0','۰').replace('1','۱').replace('2','۲').replace('3','۳').replace('4','۴').replace('5','۵').replace('6','۶').replace('7','۷').replace('8','۸').replace('9','۹'); }
    private static class Slot { int start,duration; String subject,topic,type; Slot(int s,int d,String sub,String t,String kind){start=s;duration=d;subject=sub;topic=t;type=kind;} }
}
